from flask import Blueprint, render_template, request, redirect, url_for
import os

# --- 1. Define the Blueprint ---
bp = Blueprint('module3', __name__, url_prefix='/module3')

# --- ROUTE 1: The New "Insert Defect" Page ---
@bp.route('/insert_defect', methods=['GET'])
def insert_defect():
    # This renders your new "One-Stop" form
    return render_template('module3/insert_defect.html')

# --- ROUTE 2: Handle the Submission ---
@bp.route('/submit_defect', methods=['POST'])
def submit_defect():
    # 1. Get Text Info
    project_name = request.form.get('project_name')
    owner_name = request.form.get('owner_name')
    description = request.form.get('description')
    unit_no = request.form.get('unit_no')
    
    # 2. Setup Upload Folder
    upload_folder = os.path.join(os.getcwd(), 'app', 'static', 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    
    # 3. Save Lidar File (Required)
    lidar_file = request.files.get('lidar_file')
    lidar_filename = "None"
    if lidar_file and lidar_file.filename != '':
        lidar_filename = lidar_file.filename
        lidar_file.save(os.path.join(upload_folder, lidar_filename))

    # 4. Save PDF/Photo Evidence (Optional)
    pdf_file = request.files.get('pdf_file')
    pdf_filename = "None"
    if pdf_file and pdf_file.filename != '':
        pdf_filename = pdf_file.filename
        pdf_file.save(os.path.join(upload_folder, pdf_filename))

    # 5. Success Message
    return f"""
    <div style="font-family: sans-serif; text-align: center; padding: 50px;">
        <h1 style="color: green;">✅ Scan Uploaded Successfully!</h1>
        <div style="background: #f0fdf4; padding: 20px; display: inline-block; border-radius: 10px; text-align: left;">
            <p><b>Project:</b> {project_name}</p>
            <p><b>Owner:</b> {owner_name}</p>
            <p><b>Unit No:</b> {unit_no}</p>
            <hr>
            <p><b>Lidar File:</b> {lidar_filename}</p>
            <p><b>Evidence File:</b> {pdf_filename}</p>
        </div>
        <br><br>
       <a href="{ url_for('module1.dashboard') }" style="text-decoration: none; background: #334155; color: white; padding: 10px 20px; border-radius: 5px;">Return to Dashboard</a>
    </div>
    """